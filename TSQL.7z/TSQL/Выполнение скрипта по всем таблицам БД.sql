
DECLARE	@Table_Name AS nvarchar(200),
		@SQL_String AS nvarchar(max)

DECLARE TablesList CURSOR STATIC FOR
SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'

OPEN TablesList
FETCH TablesList INTO @Table_Name

WHILE @@FETCH_STATUS = 0
	BEGIN
	
	SET @SQL_String =	N'USE [MONITOR16]
ALTER TABLE [dbo].['+@Table_Name+'] REBUILD PARTITION = ALL
WITH 
(DATA_COMPRESSION = PAGE
)'
	

	EXECUTE sp_executesql @SQL_String

	
	FETCH NEXT FROM TablesList INTO @Table_Name

	END

	CLOSE TablesList;
	DEALLOCATE TablesList;



