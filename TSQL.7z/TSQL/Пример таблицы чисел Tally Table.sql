


DROP TABLE IF EXISTS #t;
WITH ten AS(
SELECT * FROM (VALUES(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) T(n)  
),
millions AS(
SELECT RowNum = ROW_NUMBER() OVER (ORDER BY (SELECT '1') )
FROM ten t1
CROSS join ten t2
--CROSS join ten t3
--CROSS join ten t4
--CROSS join ten t5
--CROSS join ten t6
--CROSS join ten t7
)
SELECT 
 ���� = DATEADD(d,RowNum-1, '20220101')
,JDE  = YEAR(DATEADD(d,RowNum-1, '20220101'))-1900 * 1000 + DAY(DATEADD(d,RowNum-1, '20220101'))
--INTO #t
FROM millions


SELECT *
FROM #t
ORDER BY ����





--===========================================
DROP TABLE IF EXISTS #t;
WITH ten AS(
SELECT n FROM (VALUES(1),(1),(1),(1),(1),(1),(1),(1),(1),(1)) T(n)  
),
millions AS(
SELECT RowNum = ROW_NUMBER() OVER (ORDER BY (SELECT 1) )
FROM ten t1
CROSS join ten t2
CROSS join ten t3
CROSS join ten t4
CROSS join ten t5
CROSS join ten t6
CROSS join ten t7
)
SELECT 
 RowNum
,d        = CASE WHEN RowNum % 2 = 0 THEN 1 ELSE 0 END
INTO #t
FROM millions



--===== Simulate a passed parameter
DECLARE @Parameter VARCHAR(8000) = ',Element01,Element02,Element03,Element04,Element05,'
--===== Do the same thing as the loop did... "Step" through the variable
     -- and return the character position and the character...
 SELECT RowNum, SUBSTRING(@Parameter,RowNum,1)
   FROM #t
  WHERE RowNum <= LEN(@Parameter)
  ORDER BY RowNum
  
  
  
  
  --======================================
  --=============================================================================
--      Setup
--=============================================================================
    USE TempDB     --DB that everyone has where we can cause no harm
    SET NOCOUNT ON --Supress the auto-display of rowcounts for appearance/speed
DECLARE @StartTime DATETIME    --Timer to measure total duration
    SET @StartTime = GETDATE() --Start the timer
CREATE TABLE dbo.Tally 
        (N INT, 
         CONSTRAINT PK_Tally_N PRIMARY KEY CLUSTERED (N))
--=============================================================================
--      Create and populate a Tally table
--=============================================================================
--===== Conditionally drop 
     IF OBJECT_ID('dbo.Tally') IS NOT NULL 
        DROP TABLE dbo.Tally
--===== Create and populate the Tally table on the fly
 SELECT TOP 11000 --equates to more than 30 years of dates
        IDENTITY(INT,1,1) AS N
   INTO dbo.Tally
   FROM Master.dbo.SysColumns sc1,
        Master.dbo.SysColumns sc2
--===== Add a Primary Key to maximize performance
  ALTER TABLE dbo.Tally
    ADD CONSTRAINT PK_Tally_N 
        PRIMARY KEY CLUSTERED (N) WITH FILLFACTOR = 100
--===== Let the public use it
  GRANT SELECT, REFERENCES ON dbo.Tally TO PUBLIC
--===== Display the total duration
 SELECT STR(DATEDIFF(ms,@StartTime,GETDATE())) + ' Milliseconds duration'




DECLARE @Parameter VARCHAR(8000)
    SET @Parameter = ',Element01,Element02,Element03,Element04,Element05,'

 SELECT N, SUBSTRING(@Parameter,N,1)
   FROM dbo.Tally
  WHERE N <= LEN(@Parameter)
  ORDER BY N