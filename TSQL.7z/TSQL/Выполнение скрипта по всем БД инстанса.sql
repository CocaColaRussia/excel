BEGIN TRAN

DECLARE	@BD_Name AS nvarchar(200),
		@SQL_String AS nvarchar(max)

DECLARE DataBasesList CURSOR STATIC FOR
SELECT [name]
FROM sys.databases
WHERE database_id > 4
   AND is_read_only = 0
   AND state_desc = 'ONLINE'
ORDER BY database_id 

OPEN DataBasesList
FETCH DataBasesList INTO @BD_Name

WHILE @@FETCH_STATUS = 0
	BEGIN
	
	SET @SQL_String =	N'USE ' +@BD_Name+ 
	' exec dbo.sql_TOP_SIZE_TABLES'
	/*' SELECT TOP 1 * FROM [dbo].[TOP_SIZE_TABLES]'*/
	

	EXECUTE sp_executesql @SQL_String

	
	FETCH NEXT FROM DataBasesList INTO @BD_Name

	END

	CLOSE DataBasesList;
	DEALLOCATE DataBasesList;



ROLLBACK TRAN	
	