--�� ����
select COUNT(*) 'Count', /*HostName, LoginName,*/ CONVERT(nvarchar, StartTime,102) 'Day',
SUM(Duration) 'Sum_Duration', SUM(Reads) 'Sum_Reads', SUM(Writes) 'Sum_Writes', SUM(CPU) 'SUM_CPU'
from [dbo].[Prof_log_read] 
WHERE TextData LIKE '%get_tempRemains%' AND StartTime >= '20211101'
GROUP BY /*HostName, LoginName,*/ CONVERT(nvarchar, StartTime,102)
ORDER BY 2 DESC

--�� HostName � LoginName. �� ����
select COUNT(*) 'Count', HostName, LoginName, CONVERT(nvarchar, StartTime,102) 'Day',
SUM(Duration) 'Sum_Duration', SUM(Reads) 'Sum_Reads', SUM(Writes) 'Sum_Writes', SUM(CPU) 'SUM_CPU'
from [dbo].[Prof_log_read] 
WHERE TextData LIKE '%get_tempRemains%' AND StartTime >= '20211101'
GROUP BY HostName, LoginName, CONVERT(nvarchar, StartTime,102)
ORDER BY 4 DESC


--������������� �� TextData
select COUNT(*) 'Count', HostName, LoginName, CONVERT(nvarchar, StartTime,102) 'Day', TextData,
SUM(Duration) 'Sum_Duration', SUM(Reads) 'Sum_Reads', SUM(Writes) 'Sum_Writes', SUM(CPU) 'SUM_CPU'
from [dbo].[Prof_log_read] 
WHERE TextData LIKE '%get_tempRemains%' AND StartTime >= '20211101'
GROUP BY HostName, LoginName, CONVERT(nvarchar, StartTime,102), TextData
ORDER BY 4 DESC

