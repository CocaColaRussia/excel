SELECT * /*TextData, Reads, StartTimeCOUNT(*), SUM(Reads)/1000000 */FROM Prof_log_read
WHERE TextData LIKE '%sp_prepexec%F550012%' AND StartTime > '2021-12-03 00:00:00.000'
ORDER BY 3 DESC

SELECT  TextData, Reads, StartTime/*COUNT(*), SUM(Reads)/1000000*/ FROM Prof_log_read
WHERE TextData LIKE '%sp_prepexec%F550012%' AND StartTime > '2021-12-02 00:00:00.000' AND StartTime < '2021-12-03 00:00:00.000' 
ORDER BY 3

