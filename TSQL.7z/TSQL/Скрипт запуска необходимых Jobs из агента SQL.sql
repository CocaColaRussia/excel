--Основная схма работы скрипта, найти задачу которая начинается на 'Reset' и запустить ее.

DECLARE @SQL NVARCHAR(MAX)
DECLARE @job SYSNAME

DECLARE jobs_cursor CURSOR
FOR
SELECT 'EXEC msdb.dbo.sp_start_job ''' + s.NAME + ''''
FROM msdb..sysjobs s
WHERE s.NAME LIKE 'Reset%'

OPEN jobs_cursor

FETCH NEXT
FROM jobs_cursor
INTO @job

WHILE @@Fetch_Status = 0
BEGIN
 PRINT @job

 EXEC sp_executesql @job_name = @job

 FETCH NEXT
 FROM jobs_cursor
 INTO @job
END

CLOSE jobs_cursor

DEALLOCATE jobs_cursor



