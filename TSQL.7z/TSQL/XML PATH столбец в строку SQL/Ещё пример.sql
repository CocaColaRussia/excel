CREATE TABLE #test (id CHAR(1), val INT);
INSERT INTO #test VALUES ('A', 1), ('A', 2), ('B', 3), ('B', 4);
SELECT * FROM #test;
GO
--********************************************************
id | val
:- | --:
A  |   1
A  |   2
B  |   3
B  |   4
--********************************************************
SELECT id,
       STUFF((SELECT ',' + CAST(val AS VARCHAR)
              FROM #test t2
              WHERE t1.id = t2.id FOR XML PATH('')),1,1,'') vals
FROM #test t1
GROUP BY id;
GO
id | vals
:- | :---
A  | 1,2 
B  | 3,4 
--********************************************************
SELECT DISTINCT
       STUFF((SELECT ',' + CAST(val AS VARCHAR)
              FROM #test t2
               FOR XML PATH('') ),1,1,'') vals
FROM #test t1;
GO
vals
:---
1,2,3,4
