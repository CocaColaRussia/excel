--USE PROFLOG

BEGIN
	
	SET NOCOUNT ON;
		   DECLARE @Start_Date datetime,
					@Start_Date1 datetime,
					@Stop_Date datetime
	       set @Start_Date= '20211205'
		   set @Start_Date1= DATEADD(d, -1, @Start_Date)
		   set @Stop_Date= DATEADD(d, 1, @Start_Date)

if OBJECT_ID('tempdb..#procs') IS NOT NULL DROP TABLE #procs
if OBJECT_ID('tempdb..#procs2') IS NOT NULL DROP TABLE #procs2
if OBJECT_ID('tempdb..#procs3') IS NOT NULL DROP TABLE #procs3
if OBJECT_ID('tempdb..#procs4') IS NOT NULL DROP TABLE #procs4

select LTRIM(convert(nvarchar(MAX), TextData)) 'TextData', Reads, DatabaseID, HostName, LoginName, Duration
into #procs
from (
	select TextData, Reads, DatabaseID, HostName, LoginName, Duration 
	FROM [dbo].[Prof_log_read] 
	where [StartTime]>@Start_Date1 and [StartTime]<@Stop_Date and DATEADD(s,+Duration/1000000,StartTime)>@Start_Date
	) as [log]
where LTRIM(lower(convert(nvarchar(MAX), TextData))) like ('%sp_cursorexecute%') 
OR LTRIM(lower(convert(nvarchar(MAX), TextData))) like ('%sp_cursorprepexec%')
OR LTRIM(lower(convert(nvarchar(MAX), TextData))) like ('%sp_cursoropen%')
OR LTRIM(lower(convert(nvarchar(MAX), TextData))) like ('%sp_prepexec%')
order by Reads desc


select 
	CASE WHEN lower(TextData) LIKE '%sp_cursorprepexec %'
OR LTRIM(lower(convert(nvarchar(MAX), TextData))) like ('%sp_cursorprepexec%')
OR LTRIM(lower(convert(nvarchar(MAX), TextData))) like ('%sp_cursoropen%')
OR LTRIM(lower(convert(nvarchar(MAX), TextData))) like ('%sp_prepexec%') THEN SUBSTRING(
		TextData, 
		patindex('%FROM %', TextData)+5, 
		datalength(TextData)-(patindex('%FROM %',lower(convert(nvarchar(MAX), TextData)))+5)
		) 
		ELSE 'NOT_FOUND_TABLE'
		END TextData, Reads, DatabaseID, HostName, LoginName, Duration
into #procs2
from #procs


 select 
	case when 
		PATINDEX('% %', replace(replace(replace(replace(TextData, ';', ' ' ), '"', ''), ']', ''), '[', '')) > 0 then -- ���� ������ ������
			SUBSTRING(replace(replace(replace(replace(TextData, ';', ' ' ), '"', ''), ']', ''), '[', ''), 1, PATINDEX('% %', replace(replace(replace(replace(TextData, ';', ' ' ), '"', ''), ']', ''), '[', ''))) -- ����� ����� ������ �� ������� ������� � ������� ������� '[', ']', '"'
		else replace(replace(replace(replace(TextData, ';', ' ' ), '"', ''), ']', ''), '[', '') end as TextData, -- ����� ������ ������� ������� '[', ']', '"'
		Reads, DatabaseID, HostName, LoginName, Duration
into #procs3
--select * from #procs2 
from #procs2 

-- ����� ������� ����� ��������� �����
select
	case 
		when REVERSE(SUBSTRING(REVERSE(TextData), 0, Patindex('%.%', REVERSE(TextData)))) = '' then TextData
		else REVERSE(SUBSTRING(REVERSE(TextData), 0, Patindex('%.%', REVERSE(TextData)))) end as TextData,Reads, 
		DatabaseID, HostName, LoginName, Duration
into #procs4
from #procs3

--SELECT * FROM #procs2
WHERE TextData LIKE '%are%'

select top 200 TextData,COUNT(1) 'Count',SUM(Reads)/1000000 'Sum_Reads'
from #procs4 
group by TextData
 --, DatabaseID, HostName, LoginName
order by SUM(Reads)/1000000 desc

END

